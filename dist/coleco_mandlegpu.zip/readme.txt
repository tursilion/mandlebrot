This will do nothing unless you have an F18A or Phoenix.

If you do have an F18A, it will generate a mandlebrot set in about 3 seconds.

Note it uses the normal bitmap mode as it was meant as a GPU demonstration, not an enhanced graphics demonstration. On the TI-99/4A, this is roughly 10 times faster than the host CPU can draw the same image. I don't have a benchmark for the ColecoVision.

The code runs entirely on the GPU, including bitmap mode setup and all calculations and drawing.
