20170225

I wrote this as a quick demonstration of the performance of the F18A GPU... it generates the basic mandlebrot set in TI bitmap mode. One version does it on the TMS9900 CPU in about 30 seconds or so. The other runs (nearly) the exact same code on the F18A GPU in less than 3 seconds. 

Both EA#5 and cartridge images are provided.
